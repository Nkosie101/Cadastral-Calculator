﻿using System;
using System.Linq;
using System.Collections.Generic;
/*using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Threading.Tasks;*/
using Surveyors_Calculator.View;
//using Surveyors_Calculator.Services;
using Android.App;
//using SQLite;
using Microsoft.Maui.Graphics;
//using CommunityToolkit.Maui.Views;
using CommunityToolkit.Maui.Core.Views;


namespace Surveyors_Calculator.ViewModel;

public partial class InputViewModel : BaseViewModel
{

    public ObservableCollection<Coordinate> Coordinates { get; } = new();
    public ObservableCollection<Coordinate> CoordinatesFromDB { get; } = new();
    public ObservableCollection<string> CoordinateSystems { get; } = new();
    public ObservableCollection<string> Units { get; } = new();


    private readonly SqliteConnectionFactory _connectionFactory;
    //private readonly IPopupService _popupService;

    Coordinate coordinate;

    public InputViewModel(SqliteConnectionFactory connectionFactory/*, IPopupService popupService*/)
    {

        _connectionFactory = connectionFactory;
        //_popupService = popupService;
        Coordinates = new ObservableCollection<Coordinate>();
        CoordinatesFromDB = new ObservableCollection<Coordinate>();

        Units.Add("metres");
        Units.Add("Inches");
        CoordinateSystems.Add("Lo 27°");
        CoordinateSystems.Add("Lo 29°");
        CoordinateSystems.Add("Lo 31°");


        SaveCommand.Execute(null);

    }


    [ObservableProperty]
    private string e1Entry = string.Empty;
    [ObservableProperty]
    private string n1Entry = string.Empty;
    [ObservableProperty]
    private string z1Entry = string.Empty;
    [ObservableProperty]
    private string name = string.Empty;
    [ObservableProperty]
    private string y = string.Empty;
    [ObservableProperty]
    private string x = string.Empty;
    [ObservableProperty]
    private string z = string.Empty;
    [ObservableProperty]
    private string selectedCoordSys;
    [ObservableProperty]
    private string selectedUnits;
    [ObservableProperty]
    private string fileName;
    [ObservableProperty]
    private string topLabel;
    [ObservableProperty]
    private int updateID = -1;
    [ObservableProperty]
    private Color editing;

    void ClearInputs()
    {
        Y = string.Empty;
        X = string.Empty;
        Z = string.Empty;
        Name = string.Empty;

        updateID = -1;
        Editing = Colors.Transparent;
    }

    [RelayCommand]
    async Task Refresh()
    {
        IsRefreshing = true;
        try
        {
            //AppShell.Current.DisplayAlert("Error", $"File 1: {SelectedFile1} File 2: {SelectedFile2}", "OK");
            LoadFile();
        }
        catch (Exception e)
        {
            await AppShell.Current.DisplayAlert("Error", $"! {e.Message}", "OK");
        }
        finally
        {
            ClearInputs();
            IsRefreshing = false;
        }
    }

    [RelayCommand]
    async Task Delete()
    {
        if (IsBusy)
            return;
        SQLiteAsyncConnection database = _connectionFactory.CreateConnection();
        try
        {
            IsBusy = true;
            var result = await AppShell.Current.DisplayAlert("Alert", "Are you sure you want to delete the selected file(s)?", "Yes", "No");
            if (result)
            {

                foreach (Coordinate coordinate in Coordinates)
                {
                    if (coordinate.IsChecked is true)
                    {
                        CoordinateDTO coordinatedto = new CoordinateDTO()
                        {
                            id = coordinate.id,
                            name = coordinate.name,
                            y = coordinate.y,
                            x = coordinate.x,
                            z = coordinate.z,
                            units = coordinate.units,
                            coordSystem = coordinate.coordSystem,
                            fileName = coordinate.fileName
                        };
                        //AppShell.Current.DisplayAlert("Error!", $"{coordinatedto.id}", "OK");
                        await database.DeleteAsync(coordinatedto.id);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            await AppShell.Current.DisplayAlert("Error!", ex.Message, "OK");
        }
        finally
        {
            RefreshCommand.Execute(null);
            IsBusy = false;
        }
    }

    [RelayCommand]
    async Task DisplayCoordinate(Coordinate coordinate)
    {
        if (coordinate is null)
            return;
        Y = Convert.ToString(coordinate.y);
        X = Convert.ToString(coordinate.x);
        Z = Convert.ToString(coordinate.z);
        Name = coordinate.name;
        SelectedUnits = coordinate.units;
        SelectedCoordSys = coordinate.coordSystem;
        updateID = coordinate.id;

        Editing = Colors.LimeGreen;

    }

    [RelayCommand]
    async Task Update()
    {
        if (IsBusy)
            return;
        SQLiteAsyncConnection database = _connectionFactory.CreateConnection();
        try
        {
            IsBusy = true;

            /*string sql = "UPDATE Coordinates SET x=?,y=?,z=? WHERE id=?" ;
            await database.ExecuteAsync(sql,Convert.ToDouble(X), Convert.ToDouble(Y), Convert.ToDouble(Z), UpdateID);*/
            //foreach (Coordinate coordinate in Coordinates)
            var coordinate = Coordinates.FirstOrDefault(p => p.id == UpdateID);


            CoordinateDTO coordinatedto = new CoordinateDTO()
            {
                name = coordinate.name,
                id = coordinate.id,
                y = Convert.ToDouble(Y),
                x = Convert.ToDouble(X),
                z = Convert.ToDouble(Z),
                coordSystem = SelectedCoordSys,
                units = SelectedUnits,
                fileName = FileName
            };

            await database.UpdateAsync(coordinatedto);
            //AppShell.Current.DisplayAlert("Error!", $"{coordinatedto.id}", "OK");
            /*var match = Coordinates.Where(s => s.name == coordinatedto.name && s.id != UpdateID);
            if (match == null)
            {
                AppShell.Current.DisplayAlert("Error!", $"{coordinatedto.coordSystem}, {coordinatedto.units}", "OK");
                //await database.UpdateAsync(coordinatedto);
            }
            foreach(Coordinate nameCheck in Coordinates)
            {
                if(nameCheck.name == coordinatedto.name && nameCheck.id==UpdateID)
                {
                    AppShell.Current.DisplayAlert("Error!", $"{coordinatedto.coordSystem}, {coordinatedto.units}", "OK");
                }
            }*/



        }
        catch (Exception ex)
        {
            await AppShell.Current.DisplayAlert("Error!", ex.Message, "OK");
        }
        finally
        {
            RefreshCommand.Execute(null);
            IsBusy = false;
        }
    }

    [RelayCommand]
    async Task Done()
    {
        if (string.IsNullOrEmpty(fileName))
        {
            await AppShell.Current.DisplayAlert("Error", "Save the file first!", "OK");
            return;
            //await AppShell.Current.GoToAsync($"{nameof(TestPage2)}?search={name1.name}");

        }
        else
        {
            await AppShell.Current.GoToAsync($"{nameof(CalculationsPage)}?filenameKey={fileName}");
        }

        //

    }

    [RelayCommand]
    public async Task Save()
    {
        //if (string.IsNullOrEmpty(fileName)
        {

            /*var result = await AppShell.Current.DisplayPromptAsync("File Name", "File name must be unique to avoid merging with existing file", "OK", "Cancel");
            */
            var viewModel = new MyPopupViewModel();
            var popup = new MyPopup(viewModel);
            var result = await AppShell.Current.ShowPopupAsync(popup);

            if (result is FileData filedata)
            {


                FileName = filedata.fileName;
                SelectedCoordSys = filedata.coordSystem;
                SelectedUnits = filedata.units;





                TopLabel = FileName + " " + SelectedCoordSys + "(" + SelectedUnits + ")";
                //await AppShell.Current.DisplayAlert("Error", $"{filedata.fileName}", "OK");
            }

            //await _popupService.ShowAlertAsync("Hello", "This is a clean MVVM popup!", "OK");


        }
        RefreshCommand.Execute(null);

    }


    /*[RelayCommand]
    private async Task OpenPopupAsync()
    {
        await _popupService.ShowAlertAsync("Hello", "This is a clean MVVM popup!", "OK");
    }*/

    [RelayCommand]
    async Task AddCoordinates()
    {
        if (UpdateID != -1)
        {
            UpdateCommand.Execute(null);
        }
        else if (!string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(selectedCoordSys) && !string.IsNullOrEmpty(selectedUnits))

        {
            if (IsBusy)
                return;

            try
            {

                IsBusy = true;
                SQLiteAsyncConnection database = _connectionFactory.CreateConnection();

                CoordinateDTO coordinateDTO = new CoordinateDTO()
                {
                    name = Name,
                    y = Convert.ToDouble(Y),
                    x = Convert.ToDouble(X),
                    z = Convert.ToDouble(Z),
                    coordSystem = SelectedCoordSys,
                    units = SelectedUnits,
                    fileName = FileName
                };



                List<CoordinateDTO> coordinateDTOs = await database.Table<CoordinateDTO>().ToListAsync();

                //await AppShell.Current.DisplayAlert("Error", $"{file1name}", "OK");
                //show();
                foreach (CoordinateDTO dto in coordinateDTOs)
                {
                    var coord = new Coordinate
                    {
                        id = dto.id,
                        name = dto.name,
                        y = dto.y,
                        x = dto.x,
                        z = dto.z,
                        coordSystem = dto.coordSystem,
                        units = dto.units,
                        fileName = dto.fileName
                    };
                    CoordinatesFromDB.Add(coord);
                }


                var match = CoordinatesFromDB.FirstOrDefault(s => s.name == coordinateDTO.name && s.fileName == coordinateDTO.fileName);

                if (match == null)
                {
                    await database.InsertAsync(coordinateDTO);

                    Coordinate trial5 = new Coordinate()
                    {
                        id = coordinateDTO.id,
                        name = coordinateDTO.name,
                        y = coordinateDTO.y,
                        x = coordinateDTO.x,
                        z = coordinateDTO.z,
                        coordSystem = coordinateDTO.coordSystem,
                        units = coordinateDTO.units,
                        fileName = coordinateDTO.fileName
                        //name = "empty"
                    };

                    Coordinates.Add(trial5);
                }

                else
                {
                    await AppShell.Current.DisplayAlert("Error!", "Coordinate already exists", "OK");
                }
            }
            catch (Exception ex)
            {
                await AppShell.Current.DisplayAlert("Error!", ex.Message, "OK");
            }
            finally
            {
                Name = "";
                Y = "";
                X = "";
                Z = "";


                IsBusy = false;
            }
        }
        else
        {
            await AppShell.Current.DisplayAlert("Error", /*"Please save the file first"*/ $"{fileName},{selectedCoordSys}, {selectedUnits}", "OK");
        }

    }

    async Task LoadFile()
    {
        SQLiteAsyncConnection database = _connectionFactory.CreateConnection();

        List<CoordinateDTO> coordinateDTOs = await database.Table<CoordinateDTO>().ToListAsync();

        var tempCoordinates = new List<Coordinate>();

        //await AppShell.Current.DisplayAlert("Error", $"{file1name}", "OK");
        //show();
        foreach (CoordinateDTO dto in coordinateDTOs)
        {
            if (dto.fileName == FileName)
            {
                var coord = new Coordinate
                {
                    //FirstName = "Nkosilamandla", // Setting properties after creation

                    //name = dto.name
                    id = dto.id,
                    name = dto.name,
                    y = dto.y,
                    x = dto.x,
                    z = dto.z,
                    coordSystem = dto.coordSystem,
                    units = dto.units,
                    fileName = dto.fileName

                };
                tempCoordinates.Add(coord);
            }
            //From.Add(coord);
            // if (file2name == "")
        }

        MainThread.BeginInvokeOnMainThread(() =>
        {
            Coordinates.Clear();
            foreach (var co in tempCoordinates)
            {
                Coordinates.Add(co);
            }

        });
    }

    /*private void CreateCSV(object sender, EventArgs e)
    {
        WorkBook workbook = WorkBook.Create(ExcelFileFormat.XLSX);

        var sheet = workbook.CreateExcelSheet("Something");

        sheet["A3"].Value = "Point Name";
        sheet["B3"].Value = "Easting(Y)";
        sheet["C3"].Value = "Northing(X)";
        sheet["D3"].Value = "Elevation(Z)";
        sheet["C1"].Value = "Coordinate Sys";
        sheet["B1"].Value = "Units";
        sheet["A1"].Value = fileName;

        for (int i = 0; i < Coordinates.Count; i++)
        {
            sheet["A" + (i + 4)].Value = Coordinates[i].name;
            sheet["B" + (i + 4)].Value = Coordinates[i].y;
            sheet["C" + (i + 4)].Value = Coordinates[i].x;
            sheet["D" + (i + 4)].Value = Coordinates[i].z;

        }

        SaveService saveService = new SaveService();
        saveService.SaveAndView($"{fileName}.xlsx, application/octet-stream", workbook.ToStream());
    }*/



    // Before database

    /*[RelayCommand]
        async Task AddData()
        {
            Coordinate coord = new Coordinate()
            {
    
                name = name,
                y = Convert.ToDouble(e1Entry),
                x = Convert.ToDouble(n1Entry),
                z = Convert.ToDouble(z1Entry),
                coordSystem = selectedUnits,
                units = selectedUnits,
                fileName = fileName
    
    
            };
    
            Coordinates.Add(coord);
        }*/

}
