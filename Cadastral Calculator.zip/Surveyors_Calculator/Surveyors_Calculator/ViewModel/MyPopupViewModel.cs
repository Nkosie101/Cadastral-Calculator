﻿using System;
using System.Linq;
using System.Collections.Generic;
using Surveyors_Calculator.View;

namespace Surveyors_Calculator.ViewModel;

public partial class MyPopupViewModel : BaseViewModel
{

    public ObservableCollection<string> CoordinateSystems { get; } = new();
    public ObservableCollection<string> Units { get; } = new();



    public MyPopupViewModel()
    {
        Units.Add("metres");
        Units.Add("Cape feet");
        CoordinateSystems.Add("Lo 27°");
        CoordinateSystems.Add("Lo 29°");
        CoordinateSystems.Add("Lo 31°");
        CoordinateSystems.Add("Local");
    }


    [ObservableProperty]
    private string selectedCoordSys;
    [ObservableProperty]
    private string selectedUnits;
    [ObservableProperty]
    private string fileName;

    // Reference to the View
    public MyPopup Instance { get; set; }

    [RelayCommand]
    public void OkButton()
    {
        // Perform your logic here (e.g., saving the name)

        FileData fileData = new FileData
        {
            fileName = FileName,
            coordSystem = SelectedCoordSys,
            units = SelectedUnits
        };
        // Close the popup
        Instance?.Close(fileData);
    }


}
