﻿using System;
using System.IO;
using Microsoft.Maui;
using Microsoft.Maui.Controls;
//using CommunityToolkit.Maui.Views;

namespace Surveyors_Calculator.View
{
    public partial class MyPopup : Popup
    {
        public MyPopup(MyPopupViewModel viewModel)
        {
            InitializeComponent();
            BindingContext = viewModel;

            viewModel.Instance = this;
        }


    }
}